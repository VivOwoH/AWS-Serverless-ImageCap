# Triggered by S3 ObjectCreated to generate thumbnail
import json
import boto3
import mysql.connector
from PIL import Image
from io import BytesIO
from urllib.parse import unquote_plus
import os

# db config from environment variables
DB_HOST = os.environ['DB_HOST']
DB_NAME = os.environ['DB_NAME'] 
DB_USER = os.environ['DB_USER']
DB_PASSWORD = os.environ['DB_PASSWORD']

s3_client = boto3.client('s3')

# thumbnail settings
THUMBNAIL_SIZE = (200, 200)
THUMBNAIL_QUALITY = 85

def get_db_connection():
    # connect to RDS
    try:
        connection = mysql.connector.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        return connection
    except mysql.connector.Error as e:
        print(f'Database connection error: {str(e)}')
        return None

def generate_thumbnail(image_data):
    # generate thumbnail using GEmini
    try:
        image = Image.open(BytesIO(image_data))
        if image.mode in ('RGBA', 'LA', 'P'):
            image = image.convert('RGB')
        
        image.thumbnail(THUMBNAIL_SIZE, Image.Resampling.LANCZOS)
        
        thumbnail_buffer = BytesIO()
        image.save(thumbnail_buffer, format='JPEG', quality=THUMBNAIL_QUALITY, optimize=True)
        thumbnail_buffer.seek(0)
        
        return thumbnail_buffer.getvalue()
    
    except Exception as e:
        print(f"Thumbnail generation error: {str(e)}")
        return f"Thumbnail generation error: {str(e)}"

def lambda_handler(event, context):
    # lambda handler for S3 ObjectCreated events
    # download img, generate thumbnail, upload to S3, update RDS DB
    for record in event['Records']:
        # sns message
        sns_message = json.loads(record['Sns']['Message'])
        # s3 event fron SNS
        for s3_record in sns_message['Records']:
            bucket = s3_record['s3']['bucket']['name']
            key = unquote_plus(s3_record['s3']['object']['key'])  # unquoting HTML form values
            
            if key.startswith('thumbnails'):
                print(f'skipping thumbnail: {key}')
                continue
            
            print(f'Processing thumbnail: {bucket}/{key}')
            
            try:
                # download img from S3
                response = s3_client.get_object(Bucket=bucket, Key=key)
                image_data = response['Body'].read()
                
                # generate caption
                thumbnail_data = generate_thumbnail(image_data)
                
                if thumbnail_data:
                    thumbnail_key = f'thumbnails/thumb_{key}'
                    
                    # upload to S3
                    s3_client.put_objcet(
                        Bucket=bucket,
                        Key=thumbnail_key,
                        Body=thumbnail_data,
                        ContentType='image/jpeg',
                        Metadata={
                            'original-key': key,
                            'thumbnail-size': f'{THUMBNAIL_SIZE[0]}x{THUMBNAIL_SIZE[1]}'
                        }
                    )
                
                print(f'Thumbnail uploaded: {thumbnail_key}')
                
                # update DB with thumbnail key
                connection = get_db_connection()
                if connection:
                    cursor = connection.cursor()
                    cursor.execute(
                        """UPDATE captions 
                        SET thumbnail_key = %s, thumbnail_generated_at = NOW() 
                        WHERE image_key = %s""",
                        (thumbnail_key, key)
                    )
                    connection.commit()
                    connection.close()
                    print(f'DB updated with thumbnail for {key}')
                    
                else:
                    print(f'DB failed to connect')
            
            except Exception as e:
                print(f'Error processing thumbnail for {key}: {str(e)}')
                    
    return {
        'statusCode': 200,
        'body': json.dumps('Thumbnail generated')
    }