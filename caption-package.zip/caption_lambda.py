# Triggered by S3 ObjectCreated events to generate captions with Gemini

import json
import boto3
import mysql.connector
import google.generativeai as genai
import base64
from urllib.parse import unquote_plus
import os

# Configure Gemini API, REPLACE with your Gemini API key
# GOOGLE_API_KEY = "AIzaSyBlEbQP4zbYOqcYL_-Sv_KhlBsfo2ZWbUE"
GOOGLE_API_KEY = os.environ['GOOGLE_API_KEY']  # set as environment variable
genai.configure(api_key=GOOGLE_API_KEY)

# Choose a Gemini model for generating captions
model = genai.GenerativeModel(model_name="gemini-2.0-pro-exp-02-05")

# db config from environment variables
DB_HOST = os.environ['DB_HOST']
DB_NAME = os.environ['DB_NAME'] 
DB_USER = os.environ['DB_USER']
DB_PASSWORD = os.environ['DB_PASSWORD']

# Initialize the S3 client outside of the handler
s3_client = boto3.client('s3')

def get_db_connection():
    # connect to RDS
    try:
        connection = mysql.connector.connect(
            host=DB_HOST,
            database=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        return connection
    except mysql.connector.Error as e:
        print(f'Database connection error: {str(e)}')
        return None

def generate_caption(image_data):
    # generate caption using GEmini
    try:
        encoded_image = base64.b64encode(image_data).decode("utf-8")
        response = model.generate_content(
            [
                {"mime_type": "image/jpeg", "data": encoded_image},
                "Caption this image, in a paragraph, focusing on the main subjects, setting, and notable features.",
            ]
        )
        return response.text if response.text else "No caption generated."
    except Exception as e:
        print(f"Caption generation error: {str(e)}")
        return f"Caption generation error: {str(e)}"

def lambda_handler(event, context):
    # lambda handler for S3 ObjectCreated events
    # download img, generate caption, update RDS DB
    for record in event['Records']:
        # sns message
        sns_message = json.loads(record['Sns']['Message'])
        # s3 event fron SNS
        for s3_record in sns_message['Records']:
            bucket = s3_record['s3']['bucket']['name']
            key = unquote_plus(s3_record['s3']['object']['key'])  # unquoting HTML form values
            
            if key.startswith('thumbnails'):
                print(f'skipping thumbnail: {key}')
                continue
            
            print(f'Processing image: {bucket}/{key}')
            
            try:
                # download img from S3
                response = s3_client.get_object(Bucket=bucket, Key=key)
                image_data = response['Body'].read()
                
                # generate caption
                caption = generate_caption(image_data)
                print(f'Caption: {caption}')
                
                # update DB with caption
                connection = get_db_connection()
                if connection:
                    cursor = connection.cursor()
                    cursor.execute(
                        """UPDATE captions 
                        SET caption = %s, caption_generated_at = NOW() 
                        WHERE image_key = %s""",
                        (caption, key)
                    )
                    connection.commit()
                    connection.close()
                    print(f'DB updated for {key}')
                    
                else:
                    print(f'DB failed to connect')
            
            except Exception as e:
                print(f'Error processing {key}: {str(e)}')
                # # update DB with error
                # try:
                #     connection = get_db_connection()
                #     if connection:
                #         cursor = connection.cursor()
                #         cursor.execute(
                #             """UPDATE captions 
                #                SET caption = %s, caption_generated_at = NOW() 
                #                WHERE image_key = %s""",
                #             (f"Error: {str(e)}", key)
                #         )
                #         connection.commit()
                #         connection.close()
                # except:
                #     pass
                        
    return {
        'statusCode': 200,
        'body': json.dumps('Caption generated')
    }
            
            
        
    